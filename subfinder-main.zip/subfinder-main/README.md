# How to install subfinder on termux

<pre><code>
wget https://github.com/JagadBumi/subfinder/raw/main/subfinder
mv subfinder ../usr/bin
chmod +x ../usr/bin/subfinder
</code></pre>
